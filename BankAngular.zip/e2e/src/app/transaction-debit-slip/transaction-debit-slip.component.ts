import { Component, OnInit } from '@angular/core';
import { Transaction} from '../Transaction'
import{TransactionServiceService} from '../transaction-service.service'
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-transaction-debit-slip',
  templateUrl: './transaction-debit-slip.component.html',
  styleUrls: ['./transaction-debit-slip.component.css']
})
export class TransactionDebitSlipComponent implements OnInit {
  transaction:Transaction;
  constructor(private service:TransactionServiceService,private router:ActivatedRoute) { }

  ngOnInit(): void {
    this.transaction=new Transaction();
    
  }

  debitwithslip(debit:Transaction){
    console.log(debit)
    this.service.debitWithSlip(debit.transAccountNumber,debit.transactionAmount,this.transaction).subscribe(
      (response)=>{
        alert("amount debited succesfully"+response.transAccountNumber+response.transactionAmount);
    
   console.log(debit.transAccountNumber);
   console.log(debit.transactionAmount);
      },
      err=>{
        alert("err");
        console.log(err);
      }
      
    )
  
  }

}
