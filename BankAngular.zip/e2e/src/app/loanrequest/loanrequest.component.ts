import { Component, OnInit } from '@angular/core';
import { TransactionServiceService } from '../transaction-service.service';
import { Loanrequest } from '../Loanrequest';

@Component({
  selector: 'app-loanrequest',
  templateUrl: './loanrequest.component.html',
  styleUrls: ['./loanrequest.component.css']
})
export class LoanrequestComponent implements OnInit {
  loanresponse:any;
  loanrequest :Loanrequest = {loanRequestId:0,loanAmount:0,loanType:"",loanTenure:0,loanRoi:0,loanStatus:"",loanEmi:0,CreditScore:0}
  constructor(private service:TransactionServiceService) { }

  ngOnInit(): void {
  }
  submit(){
    this.loanrequest.loanStatus="Accepted";
    console.log(this.loanrequest);
    this.service.approveLoan(this.loanrequest).subscribe( data => {
      if(data.loanStatus=="Accepted"){
        alert("Loan Approved Successfully");
      }
      else if(data.loanStatus=="Rejected"){
        alert("Loan Rejected Due To Less Credit Score");
      }
     } );
  }


}
