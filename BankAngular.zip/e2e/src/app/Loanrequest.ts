export interface Loanrequest{
    loanRequestId:number;
    loanAmount:number;
    loanType:string;
    loanTenure:number;
    loanRoi:number;
    loanStatus:string;
    loanEmi:number;
    CreditScore:number;
}