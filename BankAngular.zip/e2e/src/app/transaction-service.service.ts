import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http'
import {Transaction} from './Transaction'
import {Cheque} from './Cheque'
import {BankAccountDetails} from './BankAccountDetails'
import { Observable } from 'rxjs';
import {Loanrequest} from './Loanrequest'
@Injectable({
  providedIn: 'root'
})
export class TransactionServiceService {
  getLoanById(accNumber: number) {
    throw new Error("Method not implemented.");
  }
  
  constructor(private httpClient:HttpClient) { }



addAccount(accountDetails:BankAccountDetails):Observable<BankAccountDetails>{
  return this.httpClient.post<BankAccountDetails>("http://localhost:8686/pecuniabank/add",accountDetails);
}



  

bankAccountDetails:BankAccountDetails;
deleteAccountById(accNumber:number):Observable<any>{
 return  this.httpClient.delete<any>("http://localhost:8686/pecuniabank/delete/accNum/"+accNumber);
}
updateAccountDetails(accountDetails:BankAccountDetails):Observable<BankAccountDetails>{
  return  this.httpClient.put<BankAccountDetails>("http://localhost:8686/pecuniabank/update/",accountDetails);
 }
 getAll():Observable<BankAccountDetails>{
  return this.httpClient.get<BankAccountDetails>("http://localhost:8686/pecuniabank/all");
}
viewAll():Observable<Array<Transaction>>{
  return this.httpClient.get<Array<Transaction>>("http://localhost:8686/passbook/getalltransactions/");
}


approveLoan(loanrequest):Observable<Loanrequest>{
  return this.httpClient.post<Loanrequest>("http://localhost:8686/loan/assign/loan/id/"+loanrequest.loanRequestId+"/"+loanrequest.CreditScore+"/"+loanrequest.loanAmount,loanrequest);
}
getLoanById1(accountId:number):Observable<Loanrequest>{
  console.log("http://localhost:8686/loan/get/"+accountId);
  return  this.httpClient.get<Loanrequest>("http://localhost:8686/loan/get/"+accountId);
 }
getAllLoans():Observable<Array<Loanrequest>>{
  return this.httpClient.get<Array<Loanrequest>>("http://localhost:8686/loan/getAllLoans");
}





debitWithSlip(transAccountNumber:number,amount:number,transaction:Transaction):Observable<Transaction>{
  console.log(transAccountNumber);
  console.log(amount);
  return this.httpClient.post<Transaction>("http://localhost:8686/transaction/debitwithslip/"+transAccountNumber+"/amount/"+amount,transaction);
}

creditWithSlip(transAccountNumber:number,amount:number,transaction:Transaction):Observable<Transaction>{
  console.log(transAccountNumber);
  console.log(amount);
  return this.httpClient.post<Transaction>("http://localhost:8686/transaction/creditwithslip/"+transAccountNumber+"/amount/"+amount,transaction);
}
debitWithCheque(transAccountNumber:number,chequeAmount:number,transaction:Transaction):Observable<Transaction>{
  console.log(transAccountNumber);
  console.log(chequeAmount);
  return this.httpClient.post<Transaction>("http://localhost:8686/transaction/debitwithcheque/"+transAccountNumber+"/amount/"+chequeAmount,transaction);
}

creditWithCheque(transAccountNumber:number,chequeAmount:number,transaction:Transaction):Observable<Transaction>{
  console.log(transAccountNumber);
  console.log(chequeAmount);
  return this.httpClient.post<Transaction>("http://localhost:8686/transaction/creditwithcheque/"+transAccountNumber+"/amount/"+chequeAmount,transaction);
}

}
