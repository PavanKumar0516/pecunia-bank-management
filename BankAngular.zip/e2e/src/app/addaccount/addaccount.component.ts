import { Component, OnInit } from '@angular/core';
import { TransactionServiceService } from '../transaction-service.service';
import { BankAccountDetails } from '../BankAccountDetails';
import { CustomerAddress } from '../CustomerAddress';

@Component({
  selector: 'app-addaccount',
  templateUrl: './addaccount.component.html',
  styleUrls: ['./addaccount.component.css']
})
export class AddaccountComponent implements OnInit {
account:BankAccountDetails;
address:CustomerAddress;
  constructor(private service:TransactionServiceService) { }

  ngOnInit(): void {
    this.account=new BankAccountDetails();
    this.account.customerAddress=new CustomerAddress();
  }

  addAccount(){
    console.log(this.account.accNumber);
    console.log(this.account.accountType);
console.log(this.account.customerAddress.addressId);
console.log(this.account.customerAddress.city);
    this.service.addAccount(this.account).subscribe(

      response=>{
        alert("account added succesfully");

      },
      err=>{
        alert("err");
        console.log(err);
      }
    )
    }
  




}
