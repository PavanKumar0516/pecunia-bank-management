
import{Cheque} from './Cheque'
import { from } from 'rxjs';
export class Transaction{
 transactionId:number;
 transAccountNumber:number;
currentBalance:number;
 transactionAmount:number;
  transactionDate:Date;
 transClosingBalance:number;
 chequeDetails:Cheque;
 
}