export class CustomerAddress{
    addressId:number;
    customerAddress1:String;
    customerAddress2:String;
    city:String;
    state:String;
    country:String;
    pincode:number;
}