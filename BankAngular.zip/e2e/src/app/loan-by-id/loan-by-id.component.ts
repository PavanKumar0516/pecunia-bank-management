import { Component, OnInit } from '@angular/core';
import { TransactionServiceService } from '../transaction-service.service';
import { Loanrequest } from '../Loanrequest';

@Component({
  selector: 'app-loan-by-id',
  templateUrl: './loan-by-id.component.html',
  styleUrls: ['./loan-by-id.component.css']
})
export class LoanByIdComponent implements OnInit {
   
  loan:Loanrequest;
  constructor(private service:TransactionServiceService) { }

  ngOnInit():void {
  }
  getLoanById(accountId:number){
    alert(accountId);
    
     this.service.getLoanById1(accountId).subscribe(
       response=>{
         this.loan=response
         console.log(this.loan);
      },
       err=>{
         console.log(err);
       }
     )

}
}