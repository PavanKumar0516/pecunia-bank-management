import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LoanByIdComponent } from './loan-by-id.component';

describe('LoanByIdComponent', () => {
  let component: LoanByIdComponent;
  let fixture: ComponentFixture<LoanByIdComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LoanByIdComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LoanByIdComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
