import { Component, OnInit } from '@angular/core';
import { Transaction } from '../Transaction';
import { TransactionServiceService } from '../transaction-service.service';
import { Router } from '@angular/router';
import { Cheque } from '../Cheque';

@Component({
  selector: 'app-debitwithcheque',
  templateUrl: './debitwithcheque.component.html',
  styleUrls: ['./debitwithcheque.component.css']
})
export class DebitwithchequeComponent implements OnInit {
  transaction:Transaction
cheque:Cheque;
  constructor(private service:TransactionServiceService,private route:Router) { }
  ngOnInit(): void {
    this.transaction=new Transaction();
    this.transaction.chequeDetails=new Cheque();
  }
  
  debitwithcheque(debit:Transaction){
    //console.log(debit)

    
    this.service.debitWithCheque(debit.transAccountNumber,this.transaction.chequeDetails.ChequeAmount,this.transaction).subscribe(
      (response)=>{
        alert("amount debited successfully");
    
   console.log(debit.transAccountNumber);
   console.log(debit.chequeDetails.ChequeAmount);
  
      },
      err=>{
        alert("err");
        console.log(err);
      }
      
    )
  
  }

}
