import { Component, OnInit } from '@angular/core';
import { Transaction } from '../Transaction';
import { TransactionServiceService } from '../transaction-service.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-creditwithslip',
  templateUrl: './creditwithslip.component.html',
  styleUrls: ['./creditwithslip.component.css']
})
export class CreditwithslipComponent implements OnInit {
  transaction:Transaction;
  constructor(private service:TransactionServiceService,private router:ActivatedRoute) { }

  ngOnInit(): void {
    this.transaction=new Transaction();
  }
  creditwithslip(credit:Transaction){
    console.log(credit)
    this.service.creditWithSlip(credit.transAccountNumber,credit.transactionAmount,this.transaction).subscribe(
      (response)=>{
        alert("amount credited succesfully"+response.transAccountNumber+":"+response.transactionAmount);
    
   console.log(credit.transAccountNumber);
   console.log(credit.transactionAmount);
      },
      err=>{
        alert("err");
        console.log(err);
      }
      
    )
  
  }

}
