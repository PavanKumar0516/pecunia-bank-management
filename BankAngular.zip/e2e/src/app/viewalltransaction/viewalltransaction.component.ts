import { Component, OnInit } from '@angular/core';
import { Transaction } from '../Transaction';
import { TransactionServiceService } from '../transaction-service.service';

@Component({
  selector: 'app-viewalltransaction',
  templateUrl: './viewalltransaction.component.html',
  styleUrls: ['./viewalltransaction.component.css']
})
export class ViewalltransactionComponent implements OnInit {
viewall:Array<Transaction>=[];

  constructor(private service:TransactionServiceService) { }

  ngOnInit(): void {
    this.service.viewAll().subscribe(
      response =>this.handleSuccessfulResponse(response),
      );
  }
  handleSuccessfulResponse(response)
  {
      this.viewall=response;
  }

}
