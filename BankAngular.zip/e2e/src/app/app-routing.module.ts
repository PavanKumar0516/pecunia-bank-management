import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { TransactionComponent } from './transaction/transaction.component';
import { TransactionDebitSlipComponent } from './transaction-debit-slip/transaction-debit-slip.component';
import { RouterlinkComponent } from './routerlink/routerlink.component';
import { CreditwithslipComponent } from './creditwithslip/creditwithslip.component';
import { DebitwithchequeComponent } from './debitwithcheque/debitwithcheque.component';
import { CreditwithchequeComponent } from './creditwithcheque/creditwithcheque.component';
import { AppComponent } from './app.component';
import { AccountmanagementComponent } from './accountmanagement/accountmanagement.component';
import { AddaccountComponent } from './addaccount/addaccount.component';
import { UpdateaccountComponent } from './updateaccount/updateaccount.component';
import { DeleteaccountComponent } from './deleteaccount/deleteaccount.component';
import { GetaccountbyidComponent } from './getaccountbyid/getaccountbyid.component';
import { GetallaccountComponent } from './getallaccount/getallaccount.component';
import { LoanComponent } from './loan/loan.component';
import { ViewalltransactionComponent } from './viewalltransaction/viewalltransaction.component';
import { LoanrequestComponent } from './loanrequest/loanrequest.component';
import { LoanByIdComponent } from './loan-by-id/loan-by-id.component';
import { AllLoansComponent } from './all-loans/all-loans.component';

const routes: Routes = [

{path:'home',component:AppComponent},
{path:'ams',component:AccountmanagementComponent},
{path:'add',component:AddaccountComponent},
{path:'loan',component:LoanComponent},
{path:'loanrequest',component:LoanrequestComponent},
{path:'LoanById',component:LoanByIdComponent},
{path:'allLoans',component:AllLoansComponent},
{path:'update/accNum',component:UpdateaccountComponent},
{path:'getall',component:GetallaccountComponent},
{path:'delete/accNum',component:DeleteaccountComponent},
{path:'get/accNum',component:GetaccountbyidComponent},


  {path:'transaction',component:TransactionComponent},
  {path:'router',component:RouterlinkComponent},
  {path:'debit-slip',component:TransactionDebitSlipComponent},
  {path:'credit-slip',component:CreditwithslipComponent},
  {path:'debit-cheque',component:DebitwithchequeComponent},
  {path:'credit-cheque',component:CreditwithchequeComponent},
  {path:'passbook', component:ViewalltransactionComponent},
  {path:'back',redirectTo:''},
  

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
