import { Component, OnInit } from '@angular/core';
import { TransactionServiceService } from '../transaction-service.service';
import { Transaction } from '../Transaction';
import { Cheque } from '../Cheque';

@Component({
  selector: 'app-creditwithcheque',
  templateUrl: './creditwithcheque.component.html',
  styleUrls: ['./creditwithcheque.component.css']
})
export class CreditwithchequeComponent implements OnInit {
transaction:Transaction;
cheque:Cheque;
  constructor(private service:TransactionServiceService) { }

  ngOnInit(): void {
    this.transaction=new Transaction();
   this.transaction.chequeDetails=new Cheque();
  }
  creditwithcheque(credit:Transaction){
    //console.log(debit)
    this.service.creditWithCheque(credit.transAccountNumber,this.transaction.chequeDetails.ChequeAmount,this.transaction).subscribe(
      (response)=>{
        alert("amount credited succesfully");
    
   console.log(credit.transAccountNumber);
   
  
      },
      err=>{
        alert("err");
        console.log(err);
      }
      
    )
  
  }
}
