export class Cheque{
 chequeId:number;
 currentBalance:number;
 ChequeAmount:number;
chequeIssueDate:Date;
 chequeClosingBalance:number;
debitAccNum:number;
chequeHolderName:string;

}