import { Component, OnInit } from '@angular/core';
import { TransactionServiceService } from '../transaction-service.service';
import { BankAccountDetails } from '../BankAccountDetails';
import { CustomerAddress } from '../CustomerAddress';

@Component({
  selector: 'app-updateaccount',
  templateUrl: './updateaccount.component.html',
  styleUrls: ['./updateaccount.component.css']
})
export class UpdateaccountComponent implements OnInit {
account:BankAccountDetails;


  constructor(private service:TransactionServiceService) { }

  ngOnInit(): void {
    this.account=new BankAccountDetails();
    this.account.customerAddress=new CustomerAddress();
  }

  updateAccountDetails(update:BankAccountDetails){
    update.customerName=this.account.customerName;
    console.log(this.account.customerName);

    this.service.updateAccountDetails(this.account).subscribe( 
      data => 
      { alert("updated successfully.");})}
  }
  err=>{
    alert("err");
    console.log(err);
  }


