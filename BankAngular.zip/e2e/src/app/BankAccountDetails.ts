import { CustomerAddress } from "./CustomerAddress";

export class BankAccountDetails{
     accNumber:number;
	 accountType: String;
	 accountInterest:number;
	 accountBalance:number;
	 accountBranchId: String;
	 customerName: String;
	 customerPhno:number;
	 accStatus: String;
	 customerAdharId:number;
	 customerPancard: String;
	 customerDob:Date;
	 customerGender: String;
	 customerAddress:CustomerAddress;
}