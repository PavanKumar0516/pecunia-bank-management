import { Component, OnInit } from '@angular/core';
import { TransactionServiceService } from '../transaction-service.service';
import { BankAccountDetails } from '../BankAccountDetails';
import { CustomerAddress } from '../CustomerAddress';

@Component({
  selector: 'app-deleteaccount',
  templateUrl: './deleteaccount.component.html',
  styleUrls: ['./deleteaccount.component.css']
})
export class DeleteaccountComponent implements OnInit {

accNumber:number;
  constructor(private service:TransactionServiceService) { }

  ngOnInit(): void {
  }
  deleteAccount(){

this.service.deleteAccountById(this.accNumber).subscribe(
  response=>{
    console.log("deleted by sucessfully");
  },
  err=>{
    console.log(err);
  }
)
  }

}
