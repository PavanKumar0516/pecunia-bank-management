import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit(): void {
  }

  transaction(){
    this.route.navigate(['/router']);
  }

}
