import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-getaccountbyid',
  templateUrl: './getaccountbyid.component.html',
  styleUrls: ['./getaccountbyid.component.css']
})
export class GetaccountbyidComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
