import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accountmanagement',
  templateUrl: './accountmanagement.component.html',
  styleUrls: ['./accountmanagement.component.css']
})
export class AccountmanagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
