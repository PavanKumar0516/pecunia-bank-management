import { Component, OnInit } from '@angular/core';
import { TransactionServiceService } from '../transaction-service.service';
import { BankAccountDetails } from '../BankAccountDetails';

@Component({
  selector: 'app-getallaccount',
  templateUrl: './getallaccount.component.html',
  styleUrls: ['./getallaccount.component.css']
})
export class GetallaccountComponent implements OnInit {

  constructor(private  service:TransactionServiceService) { }
getall:Array<BankAccountDetails>;
getNum:BankAccountDetails;
  ngOnInit(): void {
    this.service.getAll().subscribe(
      response =>this.handleSuccessfulResponse(response),
     );
  }
  
  handleSuccessfulResponse(response)
{
    this.getall=response;
}

}
