import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-routerlink',
  templateUrl: './routerlink.component.html',
  styleUrls: ['./routerlink.component.css']
})
export class RouterlinkComponent implements OnInit {

  constructor(private route:Router) { }

  ngOnInit(): void {
  }
  debitSlip(){
    this.route.navigate(['/debit-slip']);
  }
  creditSlip(){
    this.route.navigate(['/credit-slip']);
  }
  DebitCheque(){
    this.route.navigate(['/debit-cheque'])
  }
  creditCheque(){
    this.route.navigate(['/credit-cheque'])
  }
}
