import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TransactionDebitSlipComponent } from './transaction-debit-slip/transaction-debit-slip.component';
import { TransactionComponent } from './transaction/transaction.component';
import { RouterlinkComponent } from './routerlink/routerlink.component';
import { HttpClientModule} from '@angular/common/http';
import { FormsModule} from '@angular/forms';
import { CreditwithslipComponent } from './creditwithslip/creditwithslip.component';
import { DebitwithchequeComponent } from './debitwithcheque/debitwithcheque.component';
import { CreditwithchequeComponent } from './creditwithcheque/creditwithcheque.component';
import { AccountmanagementComponent } from './accountmanagement/accountmanagement.component';
import { AddaccountComponent } from './addaccount/addaccount.component';
import { UpdateaccountComponent } from './updateaccount/updateaccount.component';
import { DeleteaccountComponent } from './deleteaccount/deleteaccount.component';
import { GetaccountbyidComponent } from './getaccountbyid/getaccountbyid.component';
import { GetallaccountComponent } from './getallaccount/getallaccount.component';
import { LoanrequestComponent } from './loanrequest/loanrequest.component';
import { ViewalltransactionComponent } from './viewalltransaction/viewalltransaction.component';
import { HeaderComponent } from './header/header.component';
import { MainComponent } from './main/main.component';
import { Ng2SearchPipeModule} from 'ng2-search-filter';
import { FooterComponent } from './footer/footer.component';
import { LoanComponent } from './loan/loan.component';
import { LoanByIdComponent } from './loan-by-id/loan-by-id.component';
import { AllLoansComponent } from './all-loans/all-loans.component';

@NgModule({
  declarations: [
    AppComponent,
    TransactionDebitSlipComponent,
    TransactionComponent,
    RouterlinkComponent,
    CreditwithslipComponent,
    DebitwithchequeComponent,
    CreditwithchequeComponent,
    AccountmanagementComponent,
    AddaccountComponent,
    UpdateaccountComponent,
    DeleteaccountComponent,
    GetaccountbyidComponent,
    GetallaccountComponent,
    LoanComponent,
    LoanrequestComponent,
    ViewalltransactionComponent,
    HeaderComponent,
    MainComponent,
    FooterComponent,
    LoanComponent,
    LoanByIdComponent,
    AllLoansComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    Ng2SearchPipeModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
