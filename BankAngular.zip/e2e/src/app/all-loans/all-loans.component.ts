import { Component, OnInit } from '@angular/core';
import { TransactionServiceService } from '../transaction-service.service';
import { Loanrequest } from '../Loanrequest';

@Component({
  selector: 'app-all-loans',
  templateUrl: './all-loans.component.html',
  styleUrls: ['./all-loans.component.css']
})
export class AllLoansComponent implements OnInit {

  constructor(private  service:TransactionServiceService) { }
  getall:Array<Loanrequest>;
  ngOnInit(): void {
    this.service.getAllLoans().subscribe(
      response =>this.handleSuccessfulResponse(response),
     );
     
  }

  handleSuccessfulResponse(response)
{
    this.getall=response;
    console.log(this.getall);

}


}
